CREATE TABLE corp_customer (id INT PRIMARY KEY, user_id VARCHAR(45));
